import turtle             # Allows us to use turtles
win = turtle.Screen()      # Creates a playground for turtles
t = turtle.Turtle()    # Create a turtle, assign to t

#commands from here to the last line can be replaced 

t.forward(50)          # Tell alex to move forward by 50 units
t.left(90)             # Tell alex to turn by 90 degrees
t.forward(50)
t.left(90)
t.forward(50)
t.left(90)
t.forward(50)

# end commands
win.mainloop()             # Wait for user to close window
